
# Supply Chain Demand Forecasting with Neural Networks

## Nexturn Training - Problem Statement 3

### Project Overview

This project develops a retail demand forecasting pipeline for
e-commerce and supply chain logistics.

The objective is to forecast daily product demand using historical
demand, product information, promotion data, regional information,
weather conditions, and shipping features.

### Dataset

The project uses a synthetic retail dataset.

Dataset dimensions:
- 100 SKUs
- 180 days
- Approximately 18,000 records

Features:
- SKU
- Product category
- Region
- Price
- Promotion
- Discount
- Temperature
- Rainfall
- Shipping delay
- Regional index
- Inventory
- Calendar features
- Lag demand
- Rolling demand

The dataset is synthetic and should not be represented as real
company or retail transaction data.

### Data Processing

The pipeline performs:

1. Data cleaning
2. Missing-value handling
3. Duplicate removal
4. Date conversion
5. Demand lag feature creation
6. Rolling average feature creation
7. Numeric feature scaling
8. Categorical feature encoding
9. Chronological training, validation, and testing split

### Neural Network

The project uses a PyTorch multilayer perceptron.

Architecture:
- Dense input layer
- Batch Normalization
- ReLU activation
- Dropout
- Dense hidden layer
- Batch Normalization
- ReLU activation
- Dropout
- Demand output layer

### Hyperparameter Tuning

Randomized parameter sampling evaluates different combinations of:

- Hidden layer dimensions
- Learning rate
- Dropout
- Weight decay

The best model is selected using validation loss.

Early stopping reduces unnecessary training.

### Baseline

Random Forest Regression is used as the baseline model.

The tuned neural network and Random Forest are compared using:

- MAE
- RMSE
- R2
- MAPE

### Evaluation

The dataset is split chronologically.

The final test set is separate from the training and validation data.

The project reports validation and holdout test performance separately.

### Visualizations

The project generates:

1. Demand distribution
2. Monthly demand
3. Training and validation loss
4. Hyperparameter convergence
5. Actual versus predicted demand
6. Residual distribution
7. Random Forest feature importance

### Project Structure

data/
    raw/
    processed/

models/
    preprocessing_pipeline.joblib
    best_demand_forecasting_model.pth
    random_forest_baseline.joblib

results/
    hyperparameter_search_results.csv
    validation_model_comparison.csv
    test_model_comparison.csv
    metrics_summary.json
    test_demand_predictions.csv
    neural_network_training_history.csv
    random_forest_feature_importance.csv

plots/
    demand distribution
    monthly demand
    training validation loss
    hyperparameter convergence
    actual predicted demand
    residual distribution
    feature importance

src/
    pipeline.py

reports/
    project summary

### Important Notes

This is a synthetic-data demonstration.

The model is intended for one-step-ahead forecasting using previous
observed demand features.

Performance on synthetic data does not establish performance on
real-world supply chain data.

For production deployment, use actual historical demand, business
constraints, and an appropriate forecasting evaluation strategy.

### Technologies

- Python
- Pandas
- NumPy
- PyTorch
- Scikit-learn
- Matplotlib
- Joblib
- Google Colab

### Conclusion

The project demonstrates a complete demand forecasting workflow,
including data preparation, feature engineering, neural network
training, randomized hyperparameter tuning, baseline comparison,
evaluation, visualization, and model artifact saving.
