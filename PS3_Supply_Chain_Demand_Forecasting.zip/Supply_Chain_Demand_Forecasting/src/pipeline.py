
"""
Supply Chain Demand Forecasting Pipeline

Problem Statement 3 - Nexturn Training

This project notebook performs:
- Dataset generation
- Data preprocessing
- Feature engineering
- Neural network training
- Hyperparameter tuning
- Random Forest comparison
- Evaluation and visualization

Run the complete workflow in Google Colab using the main notebook.
"""

import pandas as pd
import numpy as np
import torch

def calculate_metrics(actual, predicted):

    from sklearn.metrics import (
        mean_absolute_error,
        mean_squared_error,
        r2_score
    )

    actual = np.asarray(actual)
    predicted = np.asarray(predicted)

    return {
        "MAE": float(
            mean_absolute_error(actual, predicted)
        ),
        "RMSE": float(
            np.sqrt(
                mean_squared_error(actual, predicted)
            )
        ),
        "R2": float(
            r2_score(actual, predicted)
        )
    }


def predict_demand(model, features, device="cpu"):

    model.eval()

    tensor = torch.tensor(
        features,
        dtype=torch.float32
    ).to(device)

    with torch.no_grad():

        predictions = model(
            tensor
        ).cpu().numpy().flatten()

    return predictions


if __name__ == "__main__":

    print(
        "Supply Chain Demand Forecasting Pipeline"
    )

    print(
        "Run the complete training workflow in Google Colab."
    )
