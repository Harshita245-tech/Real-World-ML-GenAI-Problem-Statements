
import os
import json
import time
import random

from typing import Literal

from pydantic import BaseModel, Field

from openai import OpenAI


MODEL_NAME = os.environ.get(
    "OPENAI_MODEL",
    "gpt-4.1-mini"
)

API_KEY = os.environ.get(
    "OPENAI_API_KEY"
)

if not API_KEY:

    raise RuntimeError(
        "Set OPENAI_API_KEY before using the production API."
    )


client = OpenAI(
    api_key=API_KEY,
    timeout=30.0,
    max_retries=0
)


class SupportTicketOutput(BaseModel):

    ticket_id: str

    category: Literal[
        "Billing",
        "Technical/API",
        "Feature Request",
        "Account",
        "Security",
        "Other"
    ]

    priority: Literal[
        "Low",
        "Medium",
        "High",
        "Critical"
    ]

    draft_response: str = Field(
        min_length=5,
        max_length=500
    )

    rationale: str = Field(
        max_length=250
    )


SYSTEM_PROMPT = """
You are an enterprise B2B SaaS support ticket router.

Classify the email into:
Billing, Technical/API, Feature Request, Account, Security, or Other.

Assign priority:
Low, Medium, High, or Critical.

Critical:
Production outage or suspected active security incident.

High:
Major technical failure or significant business impact.

Medium:
Normal billing or account support.

Low:
General questions or non-urgent feature requests.

Never request passwords, secret keys, or access tokens.

Do not claim an issue is resolved.

Return only structured JSON matching the schema.

The rationale must be a brief evidence summary.
Do not reveal hidden chain-of-thought.
"""


def route_ticket(
    ticket_id,
    email,
    max_retries=5
):

    prompt = f"""
Ticket ID:
{ticket_id}

Customer email:
{email}

Classify this support ticket.
Return the required structured JSON.
"""

    for attempt in range(max_retries):

        try:

            response = client.responses.create(
                model=MODEL_NAME,
                instructions=SYSTEM_PROMPT,
                input=prompt,
                text={
                    "format": {
                        "type": "json_schema",
                        "name": "support_ticket",
                        "strict": True,
                        "schema": SupportTicketOutput.model_json_schema()
                    }
                }
            )

            result = json.loads(
                response.output_text
            )

            validated = (
                SupportTicketOutput.model_validate(
                    result
                )
            )

            return validated.model_dump()

        except Exception as error:

            if attempt == max_retries - 1:

                raise

            delay = (
                2 ** attempt
                + random.uniform(0, 0.5)
            )

            time.sleep(
                delay
            )


if __name__ == "__main__":

    result = route_ticket(
        ticket_id="TICKET_0001",
        email=(
            "Our production API is down "
            "and customer transactions have stopped."
        )
    )

    print(
        json.dumps(
            result,
            indent=4
        )
    )
