
# Enterprise Customer Support Intent Router

## Nexturn Training - Problem Statement 4

### Project Overview

This project implements a GenAI-powered customer support
intent router for enterprise B2B SaaS helpdesk automation.

The system processes unstructured customer emails and produces
structured ticket classifications and concise customer responses.

### Main Features

- Generative AI integration
- OpenAI API wrapper
- Zero-shot prompt engineering
- Few-shot prompt engineering
- Reasoning-guided prompting
- Structured JSON output
- Pydantic validation
- API retry handling
- Exponential backoff
- Rate-limit handling
- Prompt benchmarking
- Latency measurement
- Classification evaluation
- Customer response generation

### Ticket Categories

- Billing
- Technical/API
- Feature Request
- Account
- Security
- Other

### Priority Levels

- Low
- Medium
- High
- Critical

### Prompt Benchmark

The project compares:

1. Zero-Shot
2. Few-Shot
3. Reasoning-Guided

Metrics:

- Category accuracy
- Priority accuracy
- Combined accuracy
- Category macro precision
- Category macro recall
- Category macro F1
- Priority macro precision
- Priority macro recall
- Priority macro F1
- Average latency
- Total latency
- Validation errors

### Structured Output

The output is validated using Pydantic.

Fields:

- ticket_id
- category
- priority
- draft_response
- rationale

The rationale is a brief evidence-based explanation.
It is not hidden chain-of-thought.

### API Reliability

The API wrapper includes:

- Retry handling
- Exponential backoff
- Random jitter
- Rate-limit handling
- Timeout handling
- Structured JSON parsing
- Schema validation

### Dataset

The included dataset is synthetic.

It is intended for project demonstration and benchmarking
the pipeline structure.

Synthetic results must not be presented as real enterprise
support performance.

### API Configuration

Set the OPENAI_API_KEY environment variable before running
the production API script.

The key is not stored in project files.

When no API key is configured, the notebook runs in local
demo mode.

Local demo results are not real LLM results.

### Project Structure

data/
    raw/
    processed/

src/
    production_support_router.py

config/
    prompt_configuration.json

results/
    prompt_benchmark_predictions.csv
    prompt_benchmark_matrix.csv
    category_classification_report.csv
    priority_classification_report.csv

plots/
    category accuracy
    priority accuracy
    category macro F1
    prompt latency
    confusion matrices
    category F1 comparison

reports/
    benchmark_summary.json

### Technologies

- Python
- OpenAI API
- Pydantic
- Pandas
- NumPy
- Matplotlib
- Scikit-learn
- Google Colab

### Conclusion

The project demonstrates an enterprise customer support
classification pipeline using LLM prompting, structured
output validation, API reliability handling, and prompt
benchmarking.

It produces structured support routing results and
benchmark artifacts for further evaluation.
