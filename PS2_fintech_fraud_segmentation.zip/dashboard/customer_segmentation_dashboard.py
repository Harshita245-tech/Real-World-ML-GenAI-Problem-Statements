
# ============================================================
# CUSTOMER SEGMENTATION DASHBOARD
# NEXTURN PROBLEM STATEMENT 2
# ============================================================

import os

import pandas as pd

import matplotlib.pyplot as plt

import seaborn as sns


# ------------------------------------------------------------
# PROJECT PATH
# ------------------------------------------------------------

PROJECT_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


# ------------------------------------------------------------
# INPUT FILE
# ------------------------------------------------------------

PROFILE_PATH = os.path.join(

    PROJECT_DIR,

    "data",

    "processed",

    "customer_profiles_with_clusters.csv"

)


# ------------------------------------------------------------
# OUTPUT DIRECTORIES
# ------------------------------------------------------------

REPORT_DIR = os.path.join(

    PROJECT_DIR,

    "reports"

)

PLOT_DIR = os.path.join(

    PROJECT_DIR,

    "plots"

)

os.makedirs(
    REPORT_DIR,
    exist_ok=True
)

os.makedirs(
    PLOT_DIR,
    exist_ok=True
)


# ------------------------------------------------------------
# LOAD CUSTOMER PROFILES
# ------------------------------------------------------------

profiles = pd.read_csv(
    PROFILE_PATH
)


# ------------------------------------------------------------
# CUSTOMER CLUSTER SUMMARY
# ------------------------------------------------------------

summary = profiles.groupby(
    "cluster"
).agg(

    customer_count=(

        "user_id",

        "count"

    ),

    average_spending=(

        "total_spending",

        "mean"

    ),

    average_transactions=(

        "total_transactions",

        "mean"

    ),

    average_fraud_rate=(

        "fraud_rate",

        "mean"

    ),

    average_income=(

        "customer_income",

        "mean"

    )

).reset_index()


# ------------------------------------------------------------
# DISPLAY DASHBOARD SUMMARY
# ------------------------------------------------------------

print("=" * 60)

print("CUSTOMER SEGMENTATION DASHBOARD")

print("=" * 60)

print(
    summary.round(2).to_string(
        index=False
    )
)


# ------------------------------------------------------------
# SAVE CLUSTER SUMMARY
# ------------------------------------------------------------

summary.to_csv(

    os.path.join(

        REPORT_DIR,

        "dashboard_cluster_summary.csv"

    ),

    index=False

)


# ------------------------------------------------------------
# CUSTOMER COUNT CHART
# ------------------------------------------------------------

plt.figure(figsize=(9, 6))

sns.barplot(

    data=summary,

    x="cluster",

    y="customer_count"

)

plt.title(
    "Customers by Cluster"
)

plt.xlabel(
    "Cluster"
)

plt.ylabel(
    "Customer Count"
)

plt.tight_layout()

plt.savefig(

    os.path.join(

        PLOT_DIR,

        "dashboard_customer_count.png"

    ),

    dpi=300

)

plt.show()


# ------------------------------------------------------------
# AVERAGE SPENDING CHART
# ------------------------------------------------------------

plt.figure(figsize=(9, 6))

sns.barplot(

    data=summary,

    x="cluster",

    y="average_spending"

)

plt.title(
    "Average Spending by Cluster"
)

plt.xlabel(
    "Cluster"
)

plt.ylabel(
    "Average Spending"
)

plt.tight_layout()

plt.savefig(

    os.path.join(

        PLOT_DIR,

        "dashboard_average_spending.png"

    ),

    dpi=300

)

plt.show()


# ------------------------------------------------------------
# FRAUD RATE CHART
# ------------------------------------------------------------

plt.figure(figsize=(9, 6))

sns.barplot(

    data=summary,

    x="cluster",

    y="average_fraud_rate"

)

plt.title(
    "Average Fraud Rate by Cluster"
)

plt.xlabel(
    "Cluster"
)

plt.ylabel(
    "Average Fraud Rate"
)

plt.tight_layout()

plt.savefig(

    os.path.join(

        PLOT_DIR,

        "dashboard_fraud_rate.png"

    ),

    dpi=300

)

plt.show()


# ------------------------------------------------------------
# TRANSACTION FREQUENCY CHART
# ------------------------------------------------------------

plt.figure(figsize=(9, 6))

sns.barplot(

    data=summary,

    x="cluster",

    y="average_transactions"

)

plt.title(
    "Average Transaction Frequency by Cluster"
)

plt.xlabel(
    "Cluster"
)

plt.ylabel(
    "Average Transactions"
)

plt.tight_layout()

plt.savefig(

    os.path.join(

        PLOT_DIR,

        "dashboard_transaction_frequency.png"

    ),

    dpi=300

)

plt.show()


# ------------------------------------------------------------
# DASHBOARD COMPLETION
# ------------------------------------------------------------

print(
    "Customer segmentation dashboard completed."
)

print(
    "Dashboard outputs saved in project folders."
)

