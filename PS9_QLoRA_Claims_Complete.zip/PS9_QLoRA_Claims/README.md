# PS9 — QLoRA Claims Processing

## Project Overview
Parameter-efficient fine-tuning for insurance claims classification using
4-bit NF4 quantization, LoRA, Hugging Face PEFT, and TRL.

## Dataset
- Total: 5,000 synthetic claim records
- Training: 4,000
- Validation: 500
- Test: 500
- Labels: APPROVE, PARTIAL_APPROVAL, DENY

The dataset is synthetic and rule-generated. It is not real historical
insurance data.

## Model Configuration
- Base model: Qwen/Qwen2.5-0.5B-Instruct
- Quantization: 4-bit NF4 with double quantization
- LoRA targets: q_proj and v_proj
- LoRA rank: 8
- LoRA alpha: 16
- Frameworks: Transformers, PEFT, TRL, BitsAndBytes
- Runtime: Google Colab Tesla T4

The original problem statement requests an 8B model. This implementation uses
a 0.5B model due to GPU memory and runtime constraints.

## Observed Results
- Training steps: 100
- Training duration: approximately 3.42 minutes
- Peak allocated GPU memory: 1.636 GB
- Base accuracy: 83.4%
- QLoRA accuracy: 97.8%
- Base macro F1: 0.8453
- QLoRA macro F1: 0.9711
- Base average latency: approximately 0.215 seconds per claim
- QLoRA average latency: approximately 0.236 seconds per claim

Metrics were measured on 500 synthetic test claims. They demonstrate learning
of synthetic labeling rules, not real-world underwriting performance.

## Project Structure
- data/: CSV dataset, train/validation/test splits, JSONL instructions
- scripts/: reusable training script
- models/qlora_adapter/: trained LoRA adapter
- outputs/: training logs
- reports/: metrics, loss chart, and performance reports
- docs/: implementation notes

## Privacy and Responsible Use
Never use identifiable claim records or PII without authorization. Real-world
deployment requires domain-expert review, representative data, bias analysis,
and regulatory validation.
