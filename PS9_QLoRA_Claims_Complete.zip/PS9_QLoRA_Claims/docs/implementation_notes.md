# PS9 Implementation Notes

## Methodology
Claims are converted into system, user, and assistant messages. The base
language model is loaded using BitsAndBytes 4-bit NF4 quantization. PEFT
attaches LoRA adapters to q_proj and v_proj. TRL SFTTrainer performs
supervised fine-tuning.

## Evaluation
The base and fine-tuned models were evaluated on the same 500 synthetic test
claims. Accuracy, macro precision, macro recall, macro F1, and average
inference latency were recorded.

## Limitations
1. Synthetic data replaces unavailable historical claims.
2. The implementation uses a 0.5B model rather than the requested 8B model.
3. The test set follows the same generated rules as the training data.
4. Results should not be generalized to real insurance claims.
