

# PS7: Autonomous Financial Analyst Agent

## Project Domain

Investment Banking & Wealth Management

## Problem Statement

Develop an autonomous financial analyst agent capable of
answering multi-part financial questions using:

- SQL database queries
- Market document retrieval
- Calculator tools
- ReAct-style reasoning and tool execution

## Architecture

User Question
     |
     v
ReAct Agent Controller
     |
     +---- SQL Query Tool
     |
     +---- Market RAG Tool
     |
     +---- Calculator Tool
     |
     v
Financial Analyst Report

## Tools Implemented

### SQL Query Tool

Retrieves client portfolio balances, income,
tax bracket, risk profile, and currency.

### Market RAG Tool

Retrieves relevant passages from uploaded
market outlook PDF/TXT documents.

### Calculator Tool

Performs restricted numeric arithmetic
using an AST allowlist.

## Agent Framework

The project demonstrates a transparent
ReAct-style workflow:

Thought
Action
Observation
Action
Observation
Final Answer

## Database

SQLite

## Retrieval

TF-IDF Vectorization

Cosine Similarity

## Trace Logging

JSON Lines format

## Output Files

- financial_analyst_report.md
- evaluation_results.json
- agent_trace.jsonl

## Dataset

All included client information is fictional.

## Disclaimer

Portfolio balance multiplied by tax bracket
is not a tax liability estimate.

This project is an educational demonstration
and is not investment, tax, or legal advice.

