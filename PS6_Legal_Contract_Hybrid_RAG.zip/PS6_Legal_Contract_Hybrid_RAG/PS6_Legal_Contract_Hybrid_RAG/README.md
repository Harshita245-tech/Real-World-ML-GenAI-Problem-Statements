
# PS6: Legal Contract Q&A with Hybrid Search

## Project Description

A legal document question-answering system built using
hybrid retrieval and Cross-Encoder reranking.

## Technologies

- Python
- Google Colab
- PyPDF
- Sentence Transformers
- BM25
- Reciprocal Rank Fusion
- Cross-Encoder
- Gemini API (optional)
- Pandas
- NumPy
- Matplotlib

## Pipeline

PDF Upload
    |
PDF Text Extraction
    |
Text Cleaning
    |
Clause-Based Chunking
    |
Sentence Transformer Embeddings
    |
Dense Retrieval + BM25
    |
Reciprocal Rank Fusion
    |
Cross-Encoder Reranking
    |
Context Compression
    |
Grounded Legal Q&A
    |
Evaluation and Reports

## Models

Embedding:
sentence-transformers/all-MiniLM-L6-v2

Reranker:
cross-encoder/ms-marco-MiniLM-L-6-v2

## How to Run

1. Open Google Colab.
2. Create a Python notebook.
3. Paste the complete PS6 code.
4. Run the cell.
5. Upload legal contract PDFs.
6. Wait for model downloads and processing.
7. Review generated answers and evaluation.
8. Download the generated ZIP.

## Outputs

- Document metadata
- Legal document chunks
- Embedding matrix
- Question-answer results
- Retrieval evaluation
- Evaluation summary
- Graphs
- Project report

## Disclaimer

This is an educational project.
It does not provide professional legal advice.
