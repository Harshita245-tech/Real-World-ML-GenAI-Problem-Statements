
# PS6: Legal Contract Q&A with Hybrid Search

## Project Overview

This project implements a legal contract question-answering
system using hybrid retrieval and Cross-Encoder reranking.

## Documents

Total legal documents loaded: 5

## Chunking

Total chunks created: 10

Chunk size: 800 characters

Overlap: 150 characters

## Retrieval Architecture

1. PDF text extraction
2. Document cleaning
3. Clause-aware chunking
4. Sentence Transformer embeddings
5. Dense vector retrieval
6. BM25 keyword retrieval
7. Reciprocal Rank Fusion
8. Cross-Encoder reranking
9. Context compression
10. Grounded answer generation

## Models

Embedding model:
sentence-transformers/all-MiniLM-L6-v2

Cross-Encoder:
cross-encoder/ms-marco-MiniLM-L-6-v2

## Evaluation

Evaluation queries: 5

Context precision: 0.2000

Context recall: 1.0000

## Important Limitations

The generated answers are based on the uploaded contract text.

The system is not a substitute for legal advice.

Evaluation queries are generated from the uploaded documents.
This is a basic retrieval evaluation and does not represent
a manually validated legal benchmark.

PDFs containing scanned images without selectable text
require OCR before extraction.

## Output Files

- document_metadata.csv
- legal_chunks.csv
- legal_chunks.json
- legal_embeddings.npy
- legal_qa_results.csv
- legal_qa_results.json
- retrieval_evaluation.csv
- evaluation_summary.json
- graphs
