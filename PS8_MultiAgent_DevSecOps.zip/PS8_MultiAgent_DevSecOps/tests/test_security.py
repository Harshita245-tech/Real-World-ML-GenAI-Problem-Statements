
import os
import sys
import unittest

sys.path.insert(
    0,
    os.path.dirname(os.path.dirname(__file__)) + "/outputs"
)

import remediated_app as app

class SecurityTests(unittest.TestCase):

    def test_parameterized_sql(self):
        source = open(app.__file__).read()
        self.assertIn(
            "cursor.execute(query, (username,))",
            source
        )

    def test_safe_command(self):
        source = open(app.__file__).read()
        self.assertIn("shell=False", source)
        self.assertIn('["cat", str(requested_file)]', source)

    def test_no_hardcoded_password(self):
        source = open(app.__file__).read()
        self.assertNotIn("admin123", source)

    def test_password_hashing(self):
        source = open(app.__file__).read()
        self.assertIn("pbkdf2_hmac", source)
        self.assertIn("compare_digest", source)

if __name__ == "__main__":
    unittest.main()
