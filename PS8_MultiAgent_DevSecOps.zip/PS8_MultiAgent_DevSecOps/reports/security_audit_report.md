
# PS8 Collaborative Multi-Agent DevSecOps

## Agents
1. Security Scanner Agent
2. Remediation Agent
3. Code Reviewer / QA Agent

## RAG
TF-IDF retrieval over the included OWASP-inspired corpus.
This is a demonstration corpus, not the complete official OWASP database.

## Workflow
Security scanning -> OWASP retrieval -> patch generation
-> syntax validation -> security checks -> unit tests
-> QA feedback -> remediation loop.

## Results

Initial findings: 4

Patches: 4

Iterations: 1

QA passed: True

Remaining findings: 0

## Limitations
This is a training implementation.
The test subprocess has a timeout but is not a hardened sandbox.
Pattern checks can miss vulnerabilities.
Use container or VM isolation for untrusted repositories.
