import os

import sqlite3
import subprocess

def get_user(username):
    conn = sqlite3.connect("users.db")
    query = "SELECT * FROM users WHERE username = ?"
    cursor = conn.cursor()
    cursor.execute(query, (username,))
    result = cursor.fetchone()
    conn.close()
    return result

def execute_command(filename):
    from pathlib import Path

    allowed_directory = Path("safe_files").resolve()
    requested_file = (
        allowed_directory / filename
    ).resolve()

    if not requested_file.is_relative_to(
        allowed_directory
    ):
        raise ValueError("Invalid file path")

    if not requested_file.is_file():
        raise FileNotFoundError("File not found")

    result = subprocess.run(
        ["cat", str(requested_file)],
        shell=False,
        capture_output=True,
        text=True,
        check=True,
        timeout=10
    )

    return result.stdout

def authenticate(password):
    stored_hash = os.environ.get(
        "ADMIN_PASSWORD_HASH", ""
    )

    salt = os.environ.get(
        "ADMIN_PASSWORD_SALT", ""
    )

    if not stored_hash or not salt:
        return False

    import hashlib
    import hmac

    candidate = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode(),
        salt.encode(),
        600000
    ).hex()

    if hmac.compare_digest(candidate, stored_hash):
        return True
    return False
