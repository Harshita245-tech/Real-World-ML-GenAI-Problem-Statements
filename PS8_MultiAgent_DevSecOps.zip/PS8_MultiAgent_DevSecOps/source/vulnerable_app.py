
import sqlite3
import subprocess

def get_user(username):
    conn = sqlite3.connect("users.db")
    query = "SELECT * FROM users WHERE username = '" + username + "'"
    cursor = conn.cursor()
    cursor.execute(query)
    result = cursor.fetchone()
    conn.close()
    return result

def execute_command(filename):
    command = "cat " + filename
    result = subprocess.run(
        command,
        shell=True,
        capture_output=True,
        text=True
    )
    return result.stdout

def authenticate(password):
    stored_password = "admin123"
    if password == stored_password:
        return True
    return False
