
# PS8 Collaborative Multi-Agent DevSecOps

LangGraph multi-agent security audit demonstration.

Agents:
- Security Scanner
- Remediation
- Code Reviewer / QA

Features:
- Local OWASP-inspired retrieval
- TF-IDF vector search
- Shared state and structured messages
- Vulnerability detection
- Patch generation
- QA validation
- Unit test subprocess
- Self-correction loop
- Audit logs and report

Important:
The local corpus is not the complete official OWASP database.
The subprocess is not a hardened sandbox.
