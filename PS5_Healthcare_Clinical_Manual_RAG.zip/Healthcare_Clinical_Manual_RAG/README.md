
# Healthcare Clinical Manual Ingestion & RAG Pipeline

## Project Overview

This project demonstrates a multi-format healthcare document
ingestion and semantic retrieval pipeline.

It processes PDF, Markdown, and TXT documents, extracts text
and metadata, compares two chunking strategies, generates
sentence embeddings, and stores vectors in a local ChromaDB
database.

## Features

- PDF ingestion using PyMuPDF
- Markdown ingestion using heading-based parsing
- TXT ingestion
- Source and section metadata
- Fixed-size chunking with overlap
- Header-based chunking
- Hugging Face Sentence Transformers embeddings
- Persistent local ChromaDB storage
- Cosine similarity retrieval
- Patient scenario retrieval
- Chunking comparison CSV
- Retrieval comparison CSV
- Visualization
- Reusable ingestion script
- Reusable retrieval script

## Embedding Model

`sentence-transformers/all-MiniLM-L6-v2`

## Vector Database

ChromaDB

## Similarity Metric

Cosine similarity

## Chunking

Fixed-size:
- Chunk size: 900 characters
- Overlap: 150 characters

Header-based:
- Markdown heading-aware splitting
- Section metadata retained

## Directory Structure

```text
Healthcare_Clinical_Manual_RAG/
├── data/
│   ├── raw/
│   │   ├── pdf/
│   │   ├── markdown/
│   │   └── text/
│   └── processed/
│       └── chunks/
├── vector_database/
├── reports/
│   └── figures/
├── scripts/
├── config/
└── README.md
```

## Run in Google Colab

1. Open Google Colab.
2. Create a new notebook.
3. Paste the complete project code.
4. Run the cell.
5. Wait for embedding generation and retrieval.
6. Download the ZIP artifact.

## Reusable Ingestion

```bash
python scripts/document_ingestion.py --input data/raw --output ingested_documents.json
```

## Reusable Retrieval

```bash
python scripts/semantic_retrieval.py --db vector_database --collection clinical_manual_header --query "How should temperature measurements be documented?"
```

## Outputs

- Ingested documents JSON
- Fixed-size chunk JSON
- Header-based chunk JSON
- Embedding NumPy files
- Chunk comparison CSV
- Retrieval results CSV
- Retrieval comparison CSV
- Chunk comparison visualization
- Retrieval similarity visualization
- Project report
- Reusable Python scripts
- Configuration JSON

## Important Disclaimer

The included clinical documents and scenarios are synthetic
educational examples.

This project is not clinically validated and must not be used
for diagnosis, treatment, emergency response, or real patient care.

Always rely on qualified healthcare professionals and
appropriate clinical guidelines.
