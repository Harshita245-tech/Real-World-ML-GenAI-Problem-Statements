# Healthcare Clinical Manual RAG Pipeline

## Project Overview
This project demonstrates multi-format ingestion, metadata extraction, chunking, embeddings, local vector storage, and semantic retrieval.

## Data Sources
- Synthetic educational PDF clinical manual
- Synthetic Markdown clinical manuals
- Synthetic plain-text clinical documentation

## Chunking Comparison
| chunking_method   |   chunk_count |   average_characters |   minimum_characters |   maximum_characters |
|:------------------|--------------:|---------------------:|---------------------:|---------------------:|
| fixed_size        |            16 |               174    |                   30 |                  524 |
| header_based      |            16 |               175.75 |                   30 |                  529 |

## Retrieval Comparison
| chunking_method   |   query_count |   retrieved_chunks |   average_similarity |   minimum_similarity |   maximum_similarity |
|:------------------|--------------:|-------------------:|---------------------:|---------------------:|---------------------:|
| fixed_size        |             8 |                 24 |             0.560219 |             0.427062 |             0.733973 |
| header_based      |             8 |                 24 |             0.560219 |             0.427062 |             0.733973 |

## Embedding Model
sentence-transformers/all-MiniLM-L6-v2

## Vector Database
ChromaDB persistent local collections

## Similarity Metric
Cosine similarity

## Safety Disclaimer
The corpus contains synthetic educational examples. The project is not clinically validated and must not be used for diagnosis, treatment, or real patient care.