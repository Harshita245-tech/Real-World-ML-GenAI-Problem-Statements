
import re
import json
from pathlib import Path
import fitz


def extract_pdf(path):

    path = Path(path)

    documents = []

    pdf = fitz.open(path)

    for page_number, page in enumerate(pdf, start=1):

        text = page.get_text("text").strip()

        if text:

            documents.append({
                "text": text,
                "metadata": {
                    "source": path.name,
                    "format": "pdf",
                    "page": page_number,
                    "section": "PDF Page"
                }
            })

    pdf.close()

    return documents


def extract_markdown(path):

    path = Path(path)

    content = path.read_text(encoding="utf-8")

    lines = content.splitlines()

    documents = []

    heading = "Introduction"

    current = []

    for line in lines:

        match = re.match(
            r"^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$",
            line
        )

        if match:

            if current:

                text = "\n".join(current).strip()

                if text:

                    documents.append({
                        "text": text,
                        "metadata": {
                            "source": path.name,
                            "format": "markdown",
                            "section": heading
                        }
                    })

            heading = match.group(2).strip()

            current = [line]

        else:

            current.append(line)

    if current:

        text = "\n".join(current).strip()

        if text:

            documents.append({
                "text": text,
                "metadata": {
                    "source": path.name,
                    "format": "markdown",
                    "section": heading
                }
            })

    return documents


def extract_txt(path):

    path = Path(path)

    text = path.read_text(encoding="utf-8").strip()

    if not text:

        return []

    return [{
        "text": text,
        "metadata": {
            "source": path.name,
            "format": "txt",
            "section": "Full Text"
        }
    }]


def ingest_directory(directory):

    directory = Path(directory)

    documents = []

    for path in directory.rglob("*"):

        if not path.is_file():

            continue

        suffix = path.suffix.lower()

        if suffix == ".pdf":

            documents.extend(extract_pdf(path))

        elif suffix in [".md", ".markdown"]:

            documents.extend(extract_markdown(path))

        elif suffix == ".txt":

            documents.extend(extract_txt(path))

    return documents


if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--input",
        required=True,
        help="Directory containing PDF, Markdown and TXT files"
    )

    parser.add_argument(
        "--output",
        default="ingested_documents.json"
    )

    args = parser.parse_args()

    documents = ingest_directory(args.input)

    with open(args.output, "w", encoding="utf-8") as file:

        json.dump(
            documents,
            file,
            indent=2,
            ensure_ascii=False
        )

    print("Documents ingested:", len(documents))
