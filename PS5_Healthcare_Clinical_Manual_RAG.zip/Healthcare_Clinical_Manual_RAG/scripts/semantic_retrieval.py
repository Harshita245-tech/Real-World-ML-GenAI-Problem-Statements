
import argparse
import chromadb

from sentence_transformers import SentenceTransformer


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--db",
        default="vector_database"
    )

    parser.add_argument(
        "--collection",
        default="clinical_manual_header"
    )

    parser.add_argument(
        "--query",
        required=True
    )

    parser.add_argument(
        "--top_k",
        type=int,
        default=3
    )

    parser.add_argument(
        "--model",
        default="sentence-transformers/all-MiniLM-L6-v2"
    )

    args = parser.parse_args()

    client = chromadb.PersistentClient(
        path=args.db
    )

    collection = client.get_collection(
        args.collection
    )

    model = SentenceTransformer(
        args.model
    )

    embedding = model.encode(
        [args.query],
        normalize_embeddings=True
    )[0]

    results = collection.query(
        query_embeddings=[embedding.tolist()],
        n_results=min(
            args.top_k,
            collection.count()
        ),
        include=[
            "documents",
            "metadatas",
            "distances"
        ]
    )

    for rank, (document, metadata, distance) in enumerate(
        zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0]
        ),
        start=1
    ):

        print("\\nRank:", rank)

        print("Similarity:", 1.0 - distance)

        print("Metadata:", metadata)

        print("Document:", document)


if __name__ == "__main__":

    main()
