
# Clinical Manual: Vital Signs

## Introduction

Vital signs are measurements used to describe basic physiological
observations. This educational manual discusses temperature,
pulse, respiratory rate, blood pressure, and oxygen saturation.

## Temperature

Temperature is a measurement of body heat.

Clinical interpretation depends on measurement method, patient context,
age, and local reference guidance.

Temperature observations should include the value, unit, measurement
method, and timestamp.

## Pulse

Pulse describes the arterial pulse rate.

Documentation should include the measured rate, rhythm observations,
measurement method, and timestamp.

## Respiratory Rate

Respiratory rate describes the number of breaths per minute.

Observations should include the measured rate, patient context,
and timestamp.

## Blood Pressure

Blood pressure is documented using systolic and diastolic values.

The measurement should include units, measurement method,
patient position when available, and timestamp.

## Oxygen Saturation

Oxygen saturation describes the percentage of hemoglobin carrying oxygen.

Documentation should include the measurement value, device,
and relevant patient context.

## Documentation

Measurements should be documented accurately.

Unexpected observations should be interpreted by qualified healthcare
professionals using the appropriate clinical context and guidelines.
