
# Clinical Manual: Patient Observation Documentation

## Patient Observation Records

Patient observation records should include the observation name,
value, unit, date, time, and measurement method.

## Missing Values

Missing observations should be identified as missing.

Do not replace missing clinical values with assumed measurements.

## Measurement Units

Units should be retained during ingestion and retrieval.

Values with different units should not be compared without
appropriate conversion.

## Data Quality

Documentation should identify inconsistent, incomplete, or
ambiguous information.

## Clinical Context

Patient observations should be considered in the context of
age, symptoms, medical history, measurement conditions,
and relevant professional guidance.

## Safety

This document is an educational example.

It does not provide diagnosis, treatment, or emergency medical advice.
