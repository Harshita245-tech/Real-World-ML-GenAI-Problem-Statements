# System Architecture

1. Shipment JSONL events enter simulated micro-batch ingestion.
2. Processed shipment records are stored in a CSV table.
3. Policy text is split into searchable sections.
4. Embeddings and BM25 provide semantic and keyword retrieval.
5. A rule-based router selects shipment, risk or policy tools.
6. Input and output checks screen for selected security patterns.
7. Functional scenarios and audit events are written to reports.

The prototype does not implement a full production stream processor,
autonomous LLM agent, Llama Guard deployment or NeMo Guardrails runtime.