"""Logistics Control Tower demonstration utilities."""
import re

INJECTION_PATTERNS = [
    r"ignore (all )?(previous|prior|above) instructions",
    r"reveal (the )?(system prompt|hidden instructions|secrets)",
    r"bypass (all )?(security|safety|guardrails)",
    r"override (the )?(system|safety) rules"
]

PII_PATTERNS = {
    "EMAIL": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
    "PHONE": r"(?<!\w)(?:\+?\d[\d ()-]{8,}\d)(?!\w)"
}

def detect_prompt_injection(text):
    return any(re.search(p, text, re.I) for p in INJECTION_PATTERNS)

def redact_pii(text):
    findings = []
    for label, pattern in PII_PATTERNS.items():
        matches = re.findall(pattern, text)
        if matches:
            findings.append({'type': label, 'count': len(matches)})
            text = re.sub(pattern, '[REDACTED_' + label + ']', text)
    return text, findings

def calculate_delay_risk(delay_hours, priority='Normal'):
    if int(delay_hours) >= 48 or str(priority).lower() == 'critical':
        return {'risk': 'High', 'action': 'Escalate and prepare recovery plan'}
    if int(delay_hours) >= 24:
        return {'risk': 'Medium', 'action': 'Review and monitor shipment'}
    return {'risk': 'Low', 'action': 'Continue routine monitoring'}
