# PS10: Enterprise Pipeline Agentic RAG System

## Domain
Global Supply Chain and Logistics Control Tower.

## Implemented components
- Simulated JSONL shipment ingestion in micro-batches.
- Shipment dataset and logistics policy PDF/text.
- Semantic embeddings and BM25 hybrid retrieval.
- Shipment status, delay-risk and policy-search tools.
- Input checks for prompt injection and PII redaction.
- Output keyword screening and security audit logging.
- Fifty functional evaluation scenarios and scorecard.
- Evaluation dashboard and architecture documentation.

## Evaluation status
The functional benchmark checks 50 scenarios. Supplementary lexical
proxy metrics are not official RAGAS scores. Official RAGAS metrics
remain unmeasured because the API account had no credits and the local
evaluation stalled. Harm evaluation is limited to functional security
checks; no model-judged harm score is claimed.

## Limitations
The dataset and policy are synthetic demonstrations. Ingestion is
simulated, the agent router is rule-based, and security checks use
custom patterns. This is a capstone prototype, not a deployed
production system or a full Llama Guard/NeMo implementation.

## Folders
- data/raw: source shipment events
- data/processed: ingested records, index and test scenarios
- data/policies: logistics policy files
- src: reusable source utilities
- reports: evaluation and security reports
- dashboard: evaluation chart
- docs: architecture documentation